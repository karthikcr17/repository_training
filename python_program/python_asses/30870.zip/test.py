msg = 'global edge'
