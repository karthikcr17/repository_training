#include <stdio.h>
int un_gi = 12;

void fun(void)
{

}
