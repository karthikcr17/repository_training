#include"mathops.h"
int dif(int a, int b)
{
	return (a - b);
}
int divi(int a, int b)
{
	return (a / b);
}
