#ifndef _MATHOPS_H
#define _MATHOPS_H

extern int sum(int, int);
extern int dif(int, int);
extern int mul(int, int);
extern int divi(int, int);

#endif
