struct b{
	int h;
};
