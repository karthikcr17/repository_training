#include <stdio.h>
int global = 1234;
int main(void)
{
	printf("exec succefull \n");
	
	return 0;
}
