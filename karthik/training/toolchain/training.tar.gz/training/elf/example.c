#include <stdio.h>

int main(void)
{
	int a;

	a = 3+

	printf("%d",36);

	printf("\n%d",a);

	return 0;
}
