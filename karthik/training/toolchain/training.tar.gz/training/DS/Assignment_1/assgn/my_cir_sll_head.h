#include <stdio.h>                                                              
#include <stdlib.h>                                                             
                                                                                
void cir_ins_beg(int);                                                              
void cir_ins_end (int);                                                             
void cir_ins_pos (int, int);                                                        
void cir_ins_before_pos (int, int);                                                 
void cir_ins_after_pos (int, int);                                                  
void cir_ins_middle (int);                                                          
void cir_ins_penultimate (int);                                                     
void cir_display(void);                                                             
void cir_ins_bef_num (int, int);                                                    
void cir_ins_aft_num (int, int);                                                    
void cir_del_pos (int);                                                             
int  cir_search (int);                                                              
~                   
