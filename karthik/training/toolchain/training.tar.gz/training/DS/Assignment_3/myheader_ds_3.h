#include <stdio.h>                                                              
#include <stdlib.h>                                                             
#define MAX 10                                                                  
#define MIN 0                                                                   
                                                                                
int sequential_search(int [], int);                                             
int binary_search(int [], int, int, int);                                       
void binary_rec_search(int [], int, int, int);                                  
                                                                                
                          
