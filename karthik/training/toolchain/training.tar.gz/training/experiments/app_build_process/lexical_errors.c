#include <stdio.h>
int main (void)
{
//	int 12a;			//identifier error
	
//	int a = 12;
	int b = 10;

//	in c;				//keyword error

	char c				//delimiter error
	
//	c =  + b;

//	printf ("%d \n", c);

//	int my-name;

	return 0;
}
