#include <stdio.h>
int main (void)
{
	int i;

//	for (i = 0; i < 11; i++)
//	;

//	int 12;



	return 0;
}
