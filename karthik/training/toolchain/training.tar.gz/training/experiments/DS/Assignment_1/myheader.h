#include <stdio.h>                                                              
#define MAX 5 

extern int stack(void);
extern int queue(void);
