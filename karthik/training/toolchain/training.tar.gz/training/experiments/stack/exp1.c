#include <stdio.h>

#if 0
int add(int a, int b)
{
	return (a + b);
}

int main(void)
{
	int a = 10, b = 20;

	int sum = add(a, b);
	
	printf ("sum = %d \n", sum);

return 0;
}
#endif

#if 1
int main (void)
{
	fun();

	return 0;
}
int fun(void)
{
	int a[3] = {1, 2, 3};
	a[3] = 20;

//	printf ("hello world \n");
	
	return 0;
}
#endif
