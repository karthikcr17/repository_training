#include <stdio.h>

int main(void)
{
	unsigned int a = 20;
	int b = -6;
	if( a < b )
		printf ("a is lessthan b \n");
	else 
		printf ("a is greater than b \n");

	return 0;
}	 
