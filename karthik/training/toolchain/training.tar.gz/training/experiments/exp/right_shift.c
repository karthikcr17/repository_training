#include <stdio.h> 

int main (void)
{

	int num = 0x815f3210;
	printf ("%x\n", num >> 3);

	return 0;
}

