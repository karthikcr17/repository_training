#include <stdio.h>

#if 1
int main(void)
{

	return (0);
}
#endif
