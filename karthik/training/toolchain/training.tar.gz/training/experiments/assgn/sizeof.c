#include <stdio.h>

// size of the basic data types
#if 0
int main(void)
{ 
	printf("size of integer data type is: %d\n", sizeof(int));
	printf("size of character data type is: %d\n", sizeof(char));
	printf("size of float data type is: %d\n", sizeof(float));
	printf("size of double data type is: %d\n", sizeof(double));

	
	return (0);
}
#endif


//size of basic unsigned data types
#if 0
int main(void)
{ 
	printf("size of unsigned  integer data type is: %d\n", sizeof(unsigned int));
	printf("size of unsigned character data type is: %d\n", sizeof(unsigned char));
//	printf("size of unsigned float data type is: %d\n", sizeof(unsigned float));
//	printf("size of unsigned double data type is: %d\n", sizeof(unsigned double));

	return (0);
}
#endif


//size of short data types	
#if 0
int main(void)
{ 

	printf("size of short integer data type is: %d\n", sizeof(short int));
	//printf("size of short character data type is: %d\n", sizeof(short char));
	//printf("size of short float data type is: %d\n", sizeof(short float));
	//printf("size of short double data type is: %d\n", sizeof(short double));
	return (0);
}
#endif


//size of long data types
#if 0
int main(void)
{ 
	printf("size of long integer data type is: %d\n", sizeof(long int));
	//printf("size of long character data type is: %d\n", sizeof(long char));
	//printf("size of long float data type is: %d\n", sizeof(long float));
	printf("size of long double data type is: %d\n", sizeof(long double));

	
	return (0);
}
#endif


//size of long long data types
#if 0
int main(void)
{ 
	printf("size of long long integer data type is: %d\n", sizeof(long long int));
	//printf("size of long long character data type is: %d\n", sizeof(long long char));
	//printf("size of long long float data type is: %d\n", sizeof(long long float));
	//printf("size of long long double data type is: %d\n", sizeof(long long double));

	
	return (0);
}
#endif


//size of short short data types
#if 0
int main(void)
{ 
	//printf("size of short short integer data type is: %d\n", sizeof(short short int));
	//printf("size of short short character data type is: %d\n", sizeof(short short char));
	//printf("size of short short float data type is: %d\n", sizeof(short short float));
	//printf("size of short short double data type is: %d\n", sizeof(short short double));

	
	return (0);
}
#endif


//size of long long long data types
#if 1
int main(void)
{ 
	//printf("size of long long long integer data type is: %d\n", sizeof(long long long int));
	//printf("size of long long long character data type is: %d\n", sizeof(long long long char));
	//printf("size of long long long float data type is: %d\n", sizeof(long long long float));
	//printf("size of long long long double data type is: %d\n", sizeof(long long long double));

	
	return (0);
}
#endif
