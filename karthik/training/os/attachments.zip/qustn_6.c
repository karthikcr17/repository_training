#include<stdio.h>
#include<unistd.h>
#include<pthread.h>

int main()
{
	





